'use client';

import { useState, useEffect, useCallback } from 'react';
import { authApi, usersApi, leaderboardApi, gamesApi, statsApi, User, GameResult } from '@/lib/api';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is logged in on mount
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = localStorage.getItem('draughts-token');
    if (!token) {
      setLoading(false);
      return;
    }

    const result = await authApi.getMe();
    if (result.success && result.data) {
      setUser(result.data.user);
    } else {
      // Token invalid, clear it
      localStorage.removeItem('draughts-token');
    }
    setLoading(false);
  };

  const register = useCallback(async (params: {
    username: string;
    email: string;
    password: string;
    country?: string;
    avatar?: string;
  }) => {
    setError(null);
    setLoading(true);
    
    const result = await authApi.register(params);
    
    if (result.success && result.data) {
      setUser(result.data.user);
      setLoading(false);
      return { success: true, user: result.data.user };
    }
    
    setError(result.error || 'Registration failed');
    setLoading(false);
    return { success: false, error: result.error };
  }, []);

  const login = useCallback(async (params: { email: string; password: string }) => {
    setError(null);
    setLoading(true);
    
    const result = await authApi.login(params);
    
    if (result.success && result.data) {
      setUser(result.data.user);
      setLoading(false);
      return { success: true, user: result.data.user };
    }
    
    setError(result.error || 'Login failed');
    setLoading(false);
    return { success: false, error: result.error };
  }, []);

  const loginWithGoogle = useCallback(async (params: {
    googleId: string;
    email: string;
    name: string;
    photoUrl?: string;
  }) => {
    setError(null);
    setLoading(true);
    
    const result = await authApi.googleSignIn(params);
    
    if (result.success && result.data) {
      setUser(result.data.user);
      setLoading(false);
      return { success: true, user: result.data.user };
    }
    
    setError(result.error || 'Google login failed');
    setLoading(false);
    return { success: false, error: result.error };
  }, []);

  const logout = useCallback(() => {
    authApi.logout();
    setUser(null);
  }, []);

  const updateProfile = useCallback(async (params: {
    username?: string;
    country?: string;
    avatar?: string;
  }) => {
    setError(null);
    
    const result = await usersApi.updateProfile(params);
    
    if (result.success && result.data) {
      setUser(result.data.user);
      return { success: true, user: result.data.user };
    }
    
    setError(result.error || 'Update failed');
    return { success: false, error: result.error };
  }, []);

  return {
    user,
    loading,
    error,
    isLoggedIn: !!user,
    register,
    login,
    loginWithGoogle,
    logout,
    updateProfile,
    checkAuth,
  };
}

export function useLeaderboard(limit = 100) {
  const [leaderboard, setLeaderboard] = useState<(User & { rank: number; winRate: number })[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchLeaderboard = useCallback(async (country?: string) => {
    setLoading(true);
    setError(null);
    
    const result = await leaderboardApi.getTop({ limit, country });
    
    if (result.success && result.data) {
      setLeaderboard(result.data.leaderboard);
    } else {
      setError(result.error || 'Failed to load leaderboard');
    }
    
    setLoading(false);
  }, [limit]);

  useEffect(() => {
    fetchLeaderboard();
  }, [fetchLeaderboard]);

  return {
    leaderboard,
    loading,
    error,
    refetch: fetchLeaderboard,
  };
}

export function useGames(limit = 20) {
  const [games, setGames] = useState<GameResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRecentGames = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    const result = await gamesApi.getRecent(limit);
    
    if (result.success && result.data) {
      setGames(result.data.games);
    } else {
      setError(result.error || 'Failed to load games');
    }
    
    setLoading(false);
  }, [limit]);

  const fetchUserGames = useCallback(async (userId: string) => {
    setLoading(true);
    setError(null);
    
    const result = await gamesApi.getUserGames(userId, limit);
    
    if (result.success && result.data) {
      setGames(result.data.games);
    } else {
      setError(result.error || 'Failed to load user games');
    }
    
    setLoading(false);
  }, [limit]);

  const submitGame = useCallback(async (params: {
    opponentId: string;
    winner: 'white' | 'black' | 'draw' | null;
    resultReason?: string;
    timeControl: number;
    movesCount?: number;
    moves?: any[];
  }) => {
    return await gamesApi.submitResult(params);
  }, []);

  useEffect(() => {
    fetchRecentGames();
  }, [fetchRecentGames]);

  return {
    games,
    loading,
    error,
    submitGame,
    fetchRecentGames,
    fetchUserGames,
  };
}

export function useStats() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalGames: 0,
    averageRating: 1500,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      const result = await statsApi.getGlobal();
      if (result.success && result.data) {
        setStats(result.data);
      }
      setLoading(false);
    };
    
    fetchStats();
  }, []);

  return { stats, loading };
}
