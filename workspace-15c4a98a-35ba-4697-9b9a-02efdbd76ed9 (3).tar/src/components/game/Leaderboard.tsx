'use client';

import { useState, useEffect } from 'react';
import { useGameStore } from '@/store/gameStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  ArrowLeft, 
  Trophy, 
  Medal, 
  TrendingUp, 
  TrendingDown,
  Crown,
  Flame,
  Search,
  Users,
  Target,
  Zap,
  Calendar,
  Clock
} from 'lucide-react';
import { cn } from '@/lib/utils';

// Country flags mapping
const COUNTRY_FLAGS: Record<string, string> = {
  'NG': '🇳🇬', 'US': '🇺🇸', 'GB': '🇬🇧', 'DE': '🇩🇪', 'FR': '🇫🇷',
  'ES': '🇪🇸', 'IT': '🇮🇹', 'NL': '🇳🇱', 'BR': '🇧🇷', 'RU': '🇷🇺',
  'CN': '🇨🇳', 'JP': '🇯🇵', 'KR': '🇰🇷', 'IN': '🇮🇳', 'AU': '🇦🇺',
  'CA': '🇨🇦', 'MX': '🇲🇽', 'AR': '🇦🇷', 'ZA': '🇿🇦', 'EG': '🇪🇬',
  'KE': '🇰🇪', 'GH': '🇬🇭', 'ET': '🇪🇹', '': '🌍'
};

// Rating tiers
const RATING_TIERS = [
  { min: 2400, name: 'Diamond', icon: '💎', color: 'text-cyan-500', bg: 'bg-cyan-500/10' },
  { min: 2100, name: 'Gold', icon: '🥇', color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
  { min: 1800, name: 'Silver', icon: '🥈', color: 'text-gray-400', bg: 'bg-gray-400/10' },
  { min: 1500, name: 'Bronze', icon: '🥉', color: 'text-orange-400', bg: 'bg-orange-400/10' },
  { min: 0, name: 'New Player', icon: '🌱', color: 'text-green-500', bg: 'bg-green-500/10' },
];

// Extended leaderboard data (simulating a real database)
const LEADERBOARD_DATA = [
  { rank: 1, name: 'GrandMaster', country: 'RU', rating: 2450, games: 520, wins: 410, avatar: '👑', trend: 'up', streak: 12 },
  { rank: 2, name: 'DraughtsKing', country: 'NL', rating: 2380, games: 430, wins: 330, avatar: '🏆', trend: 'up', streak: 8 },
  { rank: 3, name: 'CheckerChamp', country: 'BR', rating: 2320, games: 380, wins: 280, avatar: '⭐', trend: 'down', streak: -3 },
  { rank: 4, name: 'BoardMaster', country: 'US', rating: 2280, games: 290, wins: 210, avatar: '🎯', trend: 'up', streak: 5 },
  { rank: 5, name: 'PieceTaker', country: 'NG', rating: 2240, games: 450, wins: 320, avatar: '🔥', trend: 'same', streak: 0 },
  { rank: 6, name: 'KingMaker', country: 'GB', rating: 2190, games: 320, wins: 220, avatar: '🧠', trend: 'up', streak: 7 },
  { rank: 7, name: 'JumpMaster', country: 'DE', rating: 2150, games: 280, wins: 190, avatar: '💪', trend: 'down', streak: -2 },
  { rank: 8, name: 'DraughtsPro', country: 'FR', rating: 2120, games: 240, wins: 160, avatar: '🎮', trend: 'up', streak: 4 },
  { rank: 9, name: 'StrategyKing', country: 'ZA', rating: 2080, games: 190, wins: 130, avatar: '🌟', trend: 'same', streak: 0 },
  { rank: 10, name: 'MoveMaster', country: 'EG', rating: 2050, games: 220, wins: 145, avatar: '🎭', trend: 'up', streak: 3 },
  { rank: 11, name: 'DraughtsQueen', country: 'IN', rating: 2010, games: 180, wins: 115, avatar: '👸', trend: 'up', streak: 6 },
  { rank: 12, name: 'CheckMate99', country: 'CN', rating: 1980, games: 310, wins: 200, avatar: '💎', trend: 'down', streak: -1 },
  { rank: 13, name: 'BoardWalker', country: 'JP', rating: 1950, games: 150, wins: 95, avatar: '🚶', trend: 'up', streak: 2 },
  { rank: 14, name: 'TacticalMind', country: 'KE', rating: 1920, games: 200, wins: 125, avatar: '🎯', trend: 'same', streak: 0 },
  { rank: 15, name: 'DraughtsHero', country: 'GH', rating: 1890, games: 170, wins: 105, avatar: '🦸', trend: 'up', streak: 4 },
];

const RECENT_GAMES = [
  { id: 1, white: 'GrandMaster', black: 'DraughtsKing', result: 'white', time: '5 min', moves: 42, date: '2 min ago' },
  { id: 2, white: 'CheckerChamp', black: 'BoardMaster', result: 'black', time: '10 min', moves: 56, date: '5 min ago' },
  { id: 3, white: 'PieceTaker', black: 'KingMaker', result: 'white', time: '15 min', moves: 38, date: '12 min ago' },
  { id: 4, white: 'JumpMaster', black: 'DraughtsPro', result: 'white', time: '10 min', moves: 45, date: '18 min ago' },
  { id: 5, white: 'StrategyKing', black: 'MoveMaster', result: 'draw', time: '20 min', moves: 68, date: '25 min ago' },
];

export function Leaderboard() {
  const { setMode, playerName, playerStats, playerCountry, playerAvatar, isLoggedIn } = useGameStore();
  const playerRating = playerStats.rating;
  const [selectedTab, setSelectedTab] = useState('top');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [displayData, setDisplayData] = useState(LEADERBOARD_DATA);
  
  // Calculate player's rank
  const playerRank = LEADERBOARD_DATA.filter(p => p.rating > playerRating).length + 1;
  
  // Get rating tier
  const getRatingTier = (rating: number) => {
    return RATING_TIERS.find(tier => rating >= tier.min) || RATING_TIERS[RATING_TIERS.length - 1];
  };
  
  // Calculate win rate
  const getWinRate = (wins: number, games: number) => {
    if (games === 0) return 0;
    return Math.round((wins / games) * 100);
  };
  
  // Filter leaderboard
  useEffect(() => {
    let filtered = [...LEADERBOARD_DATA];
    
    if (searchQuery.trim()) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (selectedCountry !== 'all') {
      filtered = filtered.filter(p => p.country === selectedCountry);
    }
    
    setDisplayData(filtered);
  }, [searchQuery, selectedCountry]);
  
  // Add player to display if logged in
  const fullDisplayData = isLoggedIn 
    ? [...displayData, { 
        rank: playerRank, 
        name: playerName, 
        country: playerCountry, 
        rating: playerRating, 
        games: playerStats.gamesPlayed, 
        wins: playerStats.gamesWon, 
        avatar: playerAvatar, 
        trend: 'same' as const, 
        streak: 0,
        isPlayer: true 
      }].sort((a, b) => b.rating - a.rating)
    : displayData;
  
  const playerTier = getRatingTier(playerRating);
  
  return (
    <div className="max-w-4xl mx-auto px-2 sm:px-4">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4 sm:mb-6">
        <Button variant="ghost" onClick={() => setMode('lobby')} className="shrink-0">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div className="flex-1">
          <h1 className="text-xl sm:text-3xl font-bold flex items-center gap-2">
            <Trophy className="h-5 w-5 sm:h-8 sm:w-8 text-yellow-500" />
            Leaderboard
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="hidden sm:flex gap-1">
            <Users className="h-3 w-3" />
            {LEADERBOARD_DATA.length + (isLoggedIn ? 1 : 0)} players
          </Badge>
        </div>
      </div>
      
      {/* Your Stats Card (if logged in) */}
      {isLoggedIn && (
        <Card className="mb-4 sm:mb-6 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border-amber-200 dark:border-amber-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Avatar className="h-14 w-14 sm:h-16 sm:w-16 border-2 border-amber-400">
                  <AvatarFallback className="text-2xl sm:text-3xl bg-amber-100 dark:bg-amber-900">{playerAvatar}</AvatarFallback>
                </Avatar>
                <span className="absolute -bottom-1 -right-1 text-base sm:text-lg">
                  {COUNTRY_FLAGS[playerCountry] || '🌍'}
                </span>
                <div className="absolute -top-1 -left-1 text-sm">{playerTier.icon}</div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-lg sm:text-xl truncate">{playerName}</span>
                  <Badge className={cn("text-xs", playerTier.color)}>{playerTier.name}</Badge>
                  <Badge variant="secondary" className="text-xs">You</Badge>
                </div>
                <div className="flex items-center gap-3 sm:gap-4 text-xs sm:text-sm text-muted-foreground mt-1">
                  <span className="flex items-center gap-1">
                    <Trophy className="h-3 w-3 sm:h-4 sm:w-4 text-yellow-500" />
                    <span className={cn("font-bold", playerTier.color)}>{playerRating}</span> Rating
                  </span>
                  <span className="flex items-center gap-1">
                    <Medal className="h-3 w-3 sm:h-4 sm:w-4" />
                    Rank #{playerRank}
                  </span>
                </div>
              </div>
              <div className="text-right hidden sm:block">
                <div className="text-3xl font-bold text-amber-600">{playerRating}</div>
                <div className="text-xs text-muted-foreground">ELO Rating</div>
              </div>
            </div>
            
            {/* Stats Grid */}
            <div className="grid grid-cols-4 gap-2 sm:gap-4 mt-4 pt-4 border-t border-amber-200 dark:border-amber-800">
              <div className="text-center">
                <div className="text-lg sm:text-2xl font-bold">{playerStats.gamesPlayed}</div>
                <div className="text-xs text-muted-foreground">Games</div>
              </div>
              <div className="text-center">
                <div className="text-lg sm:text-2xl font-bold text-green-500">{playerStats.gamesWon}</div>
                <div className="text-xs text-muted-foreground">Wins</div>
              </div>
              <div className="text-center">
                <div className="text-lg sm:text-2xl font-bold text-red-500">{playerStats.gamesLost}</div>
                <div className="text-xs text-muted-foreground">Losses</div>
              </div>
              <div className="text-center">
                <div className="text-lg sm:text-2xl font-bold text-amber-500">
                  {playerStats.gamesPlayed > 0 ? getWinRate(playerStats.gamesWon, playerStats.gamesPlayed) : 0}%
                </div>
                <div className="text-xs text-muted-foreground">Win Rate</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="top" className="gap-1">
            <Trophy className="h-4 w-4" />
            <span className="hidden sm:inline">Top</span> Players
          </TabsTrigger>
          <TabsTrigger value="recent" className="gap-1">
            <Clock className="h-4 w-4" />
            Recent Games
          </TabsTrigger>
        </TabsList>
        
        {/* Top Players */}
        <TabsContent value="top">
          {/* Search and Filter */}
          <div className="flex gap-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search players..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedCountry} onValueChange={setSelectedCountry}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Country" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Countries</SelectItem>
                <SelectItem value="NG">🇳🇬 Nigeria</SelectItem>
                <SelectItem value="US">🇺🇸 USA</SelectItem>
                <SelectItem value="GB">🇬🇧 UK</SelectItem>
                <SelectItem value="DE">🇩🇪 Germany</SelectItem>
                <SelectItem value="FR">🇫🇷 France</SelectItem>
                <SelectItem value="BR">🇧🇷 Brazil</SelectItem>
                <SelectItem value="ZA">🇿🇦 South Africa</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {fullDisplayData.slice(0, 50).map((player, index) => {
                  const tier = getRatingTier(player.rating);
                  const isPlayer = (player as any).isPlayer;
                  
                  return (
                    <div 
                      key={`${player.rank}-${player.name}`}
                      className={cn(
                        "flex items-center gap-3 p-3 sm:p-4 transition-colors",
                        index < 3 && "bg-gradient-to-r from-yellow-50/50 to-transparent dark:from-yellow-900/10",
                        isPlayer && "bg-amber-50 dark:bg-amber-900/20 border-l-4 border-amber-500"
                      )}
                    >
                      {/* Rank */}
                      <div className="w-8 sm:w-10 flex justify-center shrink-0">
                        {player.rank === 1 ? (
                          <Crown className="h-5 w-5 sm:h-6 sm:w-6 text-yellow-500" />
                        ) : player.rank === 2 ? (
                          <Medal className="h-5 w-5 sm:h-6 sm:w-6 text-gray-400" />
                        ) : player.rank === 3 ? (
                          <Medal className="h-5 w-5 sm:h-6 sm:w-6 text-amber-600" />
                        ) : (
                          <span className="font-bold text-muted-foreground">{player.rank}</span>
                        )}
                      </div>
                      
                      {/* Avatar & Country */}
                      <div className="relative shrink-0">
                        <Avatar className={cn(
                          "h-9 w-9 sm:h-10 sm:w-10",
                          isPlayer && "ring-2 ring-amber-500"
                        )}>
                          <AvatarFallback className={cn("text-lg sm:text-xl", tier.bg)}>{player.avatar}</AvatarFallback>
                        </Avatar>
                        <span className="absolute -bottom-1 -right-1 text-xs">
                          {COUNTRY_FLAGS[player.country] || '🌍'}
                        </span>
                      </div>
                      
                      {/* Name & Stats */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "font-semibold truncate text-sm sm:text-base",
                            isPlayer && "text-amber-600"
                          )}>
                            {player.name}
                          </span>
                          <span className="text-xs">{tier.icon}</span>
                          {isPlayer && <Badge variant="secondary" className="text-xs">You</Badge>}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{player.games} games</span>
                          <span>•</span>
                          <span>{getWinRate(player.wins, player.games)}% win</span>
                        </div>
                      </div>
                      
                      {/* Trend/Streak */}
                      <div className="hidden sm:flex items-center gap-1 shrink-0">
                        {player.trend === 'up' && (
                          <div className="flex items-center text-green-500 text-xs">
                            <TrendingUp className="h-4 w-4 mr-1" />
                            {player.streak > 0 && `+${player.streak}`}
                          </div>
                        )}
                        {player.trend === 'down' && (
                          <div className="flex items-center text-red-500 text-xs">
                            <TrendingDown className="h-4 w-4 mr-1" />
                            {player.streak}
                          </div>
                        )}
                        {player.trend === 'same' && <div className="h-4 w-4" />}
                      </div>
                      
                      {/* Rating */}
                      <div className="text-right shrink-0">
                        <div className={cn("font-bold text-lg sm:text-xl", tier.color)}>{player.rating}</div>
                        <div className="text-xs text-muted-foreground hidden sm:block">{tier.name}</div>
                      </div>
                    </div>
                  );
                })}
                
                {fullDisplayData.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No players found matching your search</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Recent Games */}
        <TabsContent value="recent">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Live Games
              </CardTitle>
              <CardDescription>Recent completed games from players worldwide</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {RECENT_GAMES.map((game) => (
                  <div key={game.id} className="flex items-center gap-3 p-3 sm:p-4 hover:bg-muted/50 transition-colors">
                    {/* Players */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 text-sm sm:text-base">
                        <span className={cn(
                          "truncate font-medium",
                          game.result === 'white' && "text-green-600 font-bold"
                        )}>
                          {game.white}
                        </span>
                        <span className="text-muted-foreground text-xs">vs</span>
                        <span className={cn(
                          "truncate font-medium",
                          game.result === 'black' && "text-green-600 font-bold"
                        )}>
                          {game.black}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        <Clock className="h-3 w-3" />
                        <span>{game.time}</span>
                        <span>•</span>
                        <span>{game.moves} moves</span>
                        <span>•</span>
                        <Calendar className="h-3 w-3" />
                        <span>{game.date}</span>
                      </div>
                    </div>
                    
                    {/* Result */}
                    <div className="flex items-center gap-2">
                      {game.result === 'draw' ? (
                        <Badge variant="outline" className="text-xs">½-½</Badge>
                      ) : (
                        <Badge variant="outline" className={cn(
                          "text-xs",
                          game.result === 'white' ? "border-green-500 text-green-600" : "border-green-500 text-green-600"
                        )}>
                          {game.result === 'white' ? '1-0' : '0-1'}
                        </Badge>
                      )}
                      <Button variant="ghost" size="sm" className="h-7 text-xs">
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Rating Info */}
      <Card className="mt-4 sm:mt-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-base sm:text-lg flex items-center gap-2">
            <Flame className="h-4 w-4 text-orange-500" />
            Rating Tiers
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-4">
            {RATING_TIERS.map((tier) => (
              <div key={tier.name} className={cn("text-center p-2 rounded-lg", tier.bg)}>
                <div className="text-xl mb-1">{tier.icon}</div>
                <div className={cn("font-bold text-sm", tier.color)}>{tier.name}</div>
                <div className="text-xs text-muted-foreground">
                  {tier.min === 0 ? '< 1500' : `${tier.min}+`}
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs sm:text-sm text-muted-foreground">
            Players are ranked by <strong>ELO rating</strong>. Win games to gain rating points,
            lose games to lose points. The amount depends on your opponent's rating - 
            beating a higher-rated player gives more points!
          </p>
          {!isLoggedIn && (
            <div className="mt-3 p-3 bg-muted rounded-lg text-sm text-center">
              <p>Sign in to track your rating and compete on the leaderboard!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
