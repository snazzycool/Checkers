// API Client for International Draughts Backend
// This file handles all communication with the backend server

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api';

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

interface User {
  id: string;
  email: string;
  username: string;
  avatar: string;
  country: string | null;
  rating: number;
  gamesPlayed: number;
  gamesWon: number;
  gamesLost: number;
  createdAt?: string;
}

interface AuthResponse {
  user: User;
  token: string;
  message: string;
}

interface GameResult {
  id: string;
  whiteId: string;
  blackId: string;
  winner: string | null;
  resultReason: string | null;
  timeControl: number;
  movesCount: number;
  endedAt: string;
  white: {
    id: string;
    username: string;
    avatar: string;
    country: string | null;
    rating: number;
  };
  black: {
    id: string;
    username: string;
    avatar: string;
    country: string | null;
    rating: number;
  };
}

// ============================================
// HELPER FUNCTIONS
// ============================================

async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  const token = localStorage.getItem('draughts-token');
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      return {
        success: false,
        error: data.error || 'An error occurred',
      };
    }
    
    return {
      success: true,
      data,
    };
  } catch (error) {
    console.error('API request failed:', error);
    return {
      success: false,
      error: 'Network error. Please check your connection.',
    };
  }
}

// ============================================
// AUTH API
// ============================================

export const authApi = {
  register: async (params: {
    username: string;
    email: string;
    password: string;
    country?: string;
    avatar?: string;
  }): Promise<ApiResponse<AuthResponse>> => {
    const result = await request<AuthResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(params),
    });
    
    if (result.success && result.data?.token) {
      localStorage.setItem('draughts-token', result.data.token);
    }
    
    return result;
  },
  
  login: async (params: {
    email: string;
    password: string;
  }): Promise<ApiResponse<AuthResponse>> => {
    const result = await request<AuthResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(params),
    });
    
    if (result.success && result.data?.token) {
      localStorage.setItem('draughts-token', result.data.token);
    }
    
    return result;
  },
  
  googleSignIn: async (params: {
    googleId: string;
    email: string;
    name: string;
    photoUrl?: string;
  }): Promise<ApiResponse<AuthResponse>> => {
    const result = await request<AuthResponse>('/auth/google', {
      method: 'POST',
      body: JSON.stringify(params),
    });
    
    if (result.success && result.data?.token) {
      localStorage.setItem('draughts-token', result.data.token);
    }
    
    return result;
  },
  
  getMe: async (): Promise<ApiResponse<{ user: User }>> => {
    return request<{ user: User }>('/auth/me');
  },
  
  logout: () => {
    localStorage.removeItem('draughts-token');
  },
};

// ============================================
// USERS API
// ============================================

export const usersApi = {
  getProfile: async (userId: string): Promise<ApiResponse<{ user: User }>> => {
    return request<{ user: User }>(`/users/${userId}`);
  },
  
  updateProfile: async (params: {
    username?: string;
    country?: string;
    avatar?: string;
  }): Promise<ApiResponse<{ user: User; message: string }>> => {
    return request<{ user: User; message: string }>('/users/profile', {
      method: 'PATCH',
      body: JSON.stringify(params),
    });
  },
};

// ============================================
// LEADERBOARD API
// ============================================

export const leaderboardApi = {
  getTop: async (params?: {
    limit?: number;
    offset?: number;
    country?: string;
  }): Promise<ApiResponse<{ leaderboard: (User & { rank: number; winRate: number })[] }>> => {
    const searchParams = new URLSearchParams();
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.offset) searchParams.set('offset', params.offset.toString());
    if (params?.country) searchParams.set('country', params.country);
    
    const queryString = searchParams.toString();
    return request<{ leaderboard: (User & { rank: number; winRate: number })[] }>(
      `/leaderboard${queryString ? `?${queryString}` : ''}`
    );
  },
  
  getUserRank: async (userId: string): Promise<ApiResponse<{ rank: number }>> => {
    return request<{ rank: number }>(`/leaderboard/rank/${userId}`);
  },
};

// ============================================
// GAMES API
// ============================================

export const gamesApi = {
  submitResult: async (params: {
    opponentId: string;
    winner: 'white' | 'black' | 'draw' | null;
    resultReason?: string;
    timeControl: number;
    movesCount?: number;
    moves?: any[];
  }): Promise<ApiResponse<{ message: string; game: GameResult }>> => {
    return request<{ message: string; game: GameResult }>('/games', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },
  
  getRecent: async (limit?: number): Promise<ApiResponse<{ games: GameResult[] }>> => {
    const searchParams = limit ? `?limit=${limit}` : '';
    return request<{ games: GameResult[] }>(`/games/recent${searchParams}`);
  },
  
  getUserGames: async (userId: string, limit?: number): Promise<ApiResponse<{ games: GameResult[] }>> => {
    const searchParams = limit ? `?limit=${limit}` : '';
    return request<{ games: GameResult[] }>(`/games/user/${userId}${searchParams}`);
  },
};

// ============================================
// STATS API
// ============================================

export const statsApi = {
  getGlobal: async (): Promise<ApiResponse<{
    totalUsers: number;
    totalGames: number;
    averageRating: number;
  }>> => {
    return request('/stats');
  },
};

// ============================================
// HEALTH CHECK
// ============================================

export const healthCheck = async (): Promise<boolean> => {
  try {
    const response = await fetch(`${API_BASE_URL.replace('/api', '')}/api/health`);
    return response.ok;
  } catch {
    return false;
  }
};

export type { User, AuthResponse, GameResult };
