# 🎮 International Draughts - APK Build & Deployment Guide

## 📱 Building the APK for Android

Your app is now set up with Capacitor! Here's how to build the APK that you can share with friends:

### Prerequisites (One-time setup on your computer)

1. **Install Android Studio** from: https://developer.android.com/studio

2. **Set up environment variables** (add to your `~/.bashrc` or `~/.zshrc`):
   ```bash
   export ANDROID_HOME=$HOME/Android/Sdk
   export PATH=$PATH:$ANDROID_HOME/emulator
   export PATH=$PATH:$ANDROID_HOME/platform-tools
   ```

3. **Install Java JDK 17** (required for Android builds)

### Build Steps

1. **Copy this project to your local machine**

2. **Install dependencies:**
   ```bash
   bun install
   # or
   npm install
   ```

3. **Build the web app and sync with Android:**
   ```bash
   bun run mobile:build
   # or
   npm run mobile:build
   ```

4. **Open in Android Studio:**
   ```bash
   bun run mobile:android
   # or
   npm run mobile:android
   ```

5. **Build the APK in Android Studio:**
   - Go to **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
   - Wait for the build to complete
   - Click **locate** to find your APK file
   - The APK will be at: `android/app/build/outputs/apk/debug/app-debug.apk`

### Share the APK with Friends

The debug APK can be shared directly with friends for testing:

1. Send them the `app-debug.apk` file
2. They need to enable "Install from unknown sources" in their Android settings
3. They can install by opening the APK file

### For Production Release (Play Store)

For a release APK to publish on Play Store:

1. In Android Studio: **Build** → **Generate Signed Bundle / APK**
2. Create a new keystore (keep this safe!)
3. Build a signed APK
4. The release APK will be in `android/app/build/outputs/apk/release/`

---

## 🎵 Adding Custom Background Music

The app generates ambient music programmatically, but you can add your own music file:

### Option 1: Replace in code

1. Put your music file (MP3 or OGG) in `public/sounds/background-music.mp3`

2. Update `src/lib/sounds.ts` to use an audio element instead of generated sounds:
   ```typescript
   // In the startBackgroundMusic method:
   startBackgroundMusic() {
     if (this.isMuted || !this.musicEnabled || this.isMusicPlaying) return;
     
     const audio = new Audio('/sounds/background-music.mp3');
     audio.loop = true;
     audio.volume = 0.15;
     audio.play();
     this.backgroundAudio = audio;
     this.isMusicPlaying = true;
   }
   
   stopBackgroundMusic() {
     if (this.backgroundAudio) {
       this.backgroundAudio.pause();
       this.backgroundAudio.currentTime = 0;
       this.backgroundAudio = null;
     }
     this.isMusicPlaying = false;
   }
   ```

### Option 2: Use your own generated music

If you want to send me a music file, I can integrate it into the app for you!

---

## 🌐 Multiplayer Hosting Guide

For online multiplayer, you need to host a WebSocket server. Here are your options:

### Option A: Railway.app (Recommended - Free tier available)

1. **Create account at** https://railway.app

2. **Create a new project** and select "Deploy from GitHub repo"

3. **Create the WebSocket server file** (see below)

4. **Set environment variables:**
   - `PORT=3003`

5. **Deploy!** Railway will give you a URL like `https://your-app.railway.app`

### WebSocket Server Code (for multiplayer)

Create a file `server.js` for the WebSocket service:

```javascript
import { createServer } from 'http';
import { Server } from 'socket.io';

const httpServer = createServer();
const io = new Server(httpServer, {
  cors: {
    origin: "*", // In production, set this to your app's domain
    methods: ["GET", "POST"]
  }
});

// Store waiting players and active games
let waitingPlayers = [];
let activeGames = new Map();

io.on('connection', (socket) => {
  console.log('Player connected:', socket.id);

  // Find a game
  socket.on('findGame', (playerInfo) => {
    if (waitingPlayers.length > 0) {
      // Match with waiting player
      const opponent = waitingPlayers.pop();
      const gameId = `game-${Date.now()}`;
      
      // Create game room
      socket.join(gameId);
      opponent.socket.join(gameId);
      
      // Randomly assign colors
      const whitePlayer = Math.random() > 0.5 ? socket.id : opponent.socket.id;
      const blackPlayer = whitePlayer === socket.id ? opponent.socket.id : socket.id;
      
      // Store game info
      activeGames.set(gameId, {
        white: whitePlayer,
        black: blackPlayer,
        board: createInitialBoard(),
        currentTurn: 'white'
      });
      
      // Notify players
      io.to(gameId).emit('gameStart', {
        gameId,
        white: whitePlayer,
        black: blackPlayer
      });
      
      socket.emit('colorAssigned', 'white');
      opponent.socket.emit('colorAssigned', 'black');
    } else {
      // Wait for opponent
      waitingPlayers.push({ socket, info: playerInfo });
      socket.emit('waiting');
    }
  });

  // Make a move
  socket.on('move', (data) => {
    const game = activeGames.get(data.gameId);
    if (game) {
      // Broadcast move to opponent
      socket.to(data.gameId).emit('opponentMove', data.move);
    }
  });

  // Chat message
  socket.on('chat', (data) => {
    socket.to(data.gameId).emit('chat', data.message);
  });

  // Disconnect
  socket.on('disconnect', () => {
    // Remove from waiting list
    waitingPlayers = waitingPlayers.filter(p => p.socket.id !== socket.id);
    
    // Notify opponent if in game
    activeGames.forEach((game, gameId) => {
      if (game.white === socket.id || game.black === socket.id) {
        socket.to(gameId).emit('opponentDisconnected');
        activeGames.delete(gameId);
      }
    });
  });
});

function createInitialBoard() {
  const board = [];
  for (let row = 0; row < 10; row++) {
    board[row] = [];
    for (let col = 0; col < 10; col++) {
      if ((row + col) % 2 === 1) {
        if (row < 4) board[row][col] = { type: 'black', isKing: false };
        else if (row > 5) board[row][col] = { type: 'white', isKing: false };
        else board[row][col] = { type: null, isKing: false };
      } else {
        board[row][col] = { type: null, isKing: false };
      }
    }
  }
  return board;
}

const PORT = process.env.PORT || 3003;
httpServer.listen(PORT, () => {
  console.log(`Draughts server running on port ${PORT}`);
});
```

### Option B: Render.com (Free)

1. Create a new Web Service at https://render.com
2. Connect your GitHub repo
3. Set build command: `npm install`
4. Set start command: `node server.js`
5. Deploy!

### Option C: Your Own Server (VPS)

If you have a VPS (like DigitalOcean, Linode, etc.):

1. SSH into your server
2. Install Node.js
3. Clone your repo
4. Run the server with PM2:
   ```bash
   npm install -g pm2
   pm2 start server.js --name draughts-server
   pm2 save
   pm2 startup
   ```

### Update App for Multiplayer

After deploying the server, update the app to connect to it:

In `src/app/page.tsx` or a socket hook, connect to your server:

```typescript
import { io } from 'socket.io-client';

// Replace with your deployed server URL
const socket = io('https://your-server-url.com');

socket.on('connect', () => {
  console.log('Connected to server!');
});
```

---

## 🎨 Current Features

✅ **Play vs Computer** - 3 difficulty levels (Easy, Medium, Hard)
✅ **Time Controls** - 5, 10, 15, 20, 30 minutes
✅ **Sound Effects** - Click, Move, Capture, Victory, Defeat sounds
✅ **Background Music** - Programmatically generated ambient music
✅ **Visual Feedback** - Difficulty level highlighting
✅ **Chess Clock Timer** - With low time warnings
✅ **Leaderboard** - Track your rating and stats
✅ **Mobile Responsive** - Works on all screen sizes
✅ **PWA Ready** - Can be installed as an app
✅ **Dark/Light Mode** - Automatic theme detection

---

## 📝 Notes

- The debug APK is for testing only - it's not optimized for Play Store
- For Play Store, you need a signed release APK
- The multiplayer feature requires hosting the WebSocket server
- All game data is stored locally on the device

---

Need help? Just ask! 🎮
