# 🚀 Backend Deployment Guide

This guide explains how to deploy the backend API for International Draughts.

## 📋 Prerequisites

1. **PostgreSQL Database** - Get a free one from:
   - [Neon](https://neon.tech) - Free tier, easiest to set up
   - [Supabase](https://supabase.com) - Free tier with dashboard
   - [Railway](https://railway.app) - Free tier
   - [Render](https://render.com) - Free tier

2. **Backend Hosting** - Options:
   - [Railway](https://railway.app) - Recommended (free tier available)
   - [Render](https://render.com) - Free tier available
   - [Fly.io](https://fly.io) - Free tier available
   - [DigitalOcean](https://digitalocean.com) - Paid

---

## 🗄️ Step 1: Create Database

### Option A: Neon (Recommended - Free)

1. Go to https://neon.tech and create account
2. Create a new project called "draughts"
3. Copy the connection string (looks like):
   ```
   postgresql://username:password@ep-xxx.us-east-2.aws.neon.tech/draughts?sslmode=require
   ```

### Option B: Supabase (Free)

1. Go to https://supabase.com and create account
2. Create a new project
3. Go to Settings → Database
4. Copy the connection string (URI format)

---

## 🚀 Step 2: Deploy Backend

### Option A: Railway (Recommended)

1. Go to https://railway.app and sign in with GitHub
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your forked repository
4. Set the root directory to: `mini-services/backend-service`
5. Add environment variables:
   ```
   DATABASE_URL=your-postgresql-connection-string
   JWT_SECRET=generate-a-random-32-character-string
   PORT=3001
   ```
6. Click "Deploy"
7. Railway will give you a URL like: `https://draughts-backend.up.railway.app`

### Option B: Render (Free)

1. Go to https://render.com and sign in
2. Click "New" → "Web Service"
3. Connect your GitHub repo
4. Set:
   - Root Directory: `mini-services/backend-service`
   - Build Command: `bun install && bunx prisma generate`
   - Start Command: `bun run start`
5. Add environment variables
6. Click "Create Web Service"
7. Render will give you: `https://draughts-backend.onrender.com`

### Option C: Manual Deployment (Any VPS)

```bash
# SSH into your server
ssh user@your-server

# Install Bun
curl -fsSL https://bun.sh/install | bash

# Clone your repo
git clone https://github.com/your-username/draughts.git
cd draughts/mini-services/backend-service

# Install dependencies
bun install

# Set up environment
cp .env.example .env
nano .env  # Edit with your values

# Push database schema
bunx prisma db push

# Start with PM2 (for production)
bun install -g pm2
pm2 start index.ts --name draughts-backend
pm2 save
pm2 startup
```

---

## 🔧 Step 3: Initialize Database

After deploying, initialize the database schema:

### If using Railway/Render:
The schema will be auto-pushed on first deploy if you add this to your start command:
```
bunx prisma db push && bun run start
```

### Or manually:
```bash
# In the backend-service directory
bunx prisma db push
```

---

## 📱 Step 4: Connect Frontend to Backend

### Update API Configuration

In your frontend code, set the API URL:

```typescript
// For development
const API_URL = 'http://localhost:3001/api';

// For production
const API_URL = 'https://your-backend-url.railway.app/api';
```

### Environment Variable in Frontend

Create `.env.local` in the main project:
```env
NEXT_PUBLIC_API_URL=https://your-backend-url.railway.app/api
```

---

## 🔐 API Endpoints

### Authentication
- `POST /api/auth/register` - Create account
- `POST /api/auth/login` - Sign in
- `POST /api/auth/google` - Google sign-in
- `GET /api/auth/me` - Get current user

### Users
- `GET /api/users/:id` - Get user profile
- `PATCH /api/users/profile` - Update profile (auth required)

### Leaderboard
- `GET /api/leaderboard` - Get top players
- `GET /api/leaderboard/rank/:userId` - Get user rank

### Games
- `POST /api/games` - Submit game result (auth required)
- `GET /api/games/recent` - Get recent games
- `GET /api/games/user/:userId` - Get user's games

### Stats
- `GET /api/stats` - Get global statistics

---

## 🧪 Testing the API

```bash
# Health check
curl https://your-backend-url/api/health

# Register user
curl -X POST https://your-backend-url/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"password123"}'

# Login
curl -X POST https://your-backend-url/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

---

## 🔄 Updating the Backend

```bash
# Pull latest changes
git pull

# If using Railway/Render, it will auto-deploy

# If using manual deployment:
cd draughts/mini-services/backend-service
bun install
bunx prisma generate
pm2 restart draughts-backend
```

---

## 📊 Monitoring

### Railway
- Built-in logs and metrics
- View in the Railway dashboard

### Render
- Built-in logs
- Metrics available

### Manual (PM2)
```bash
pm2 logs draughts-backend
pm2 monit
```

---

## 🛡️ Security Notes

1. **Never commit `.env` file** - Use `.env.example` as template
2. **Use strong JWT_SECRET** - Generate with: `openssl rand -base64 32`
3. **Enable SSL** - Most hosting providers do this automatically
4. **Rate limiting** - Consider adding for production
5. **CORS** - Restrict `origin` to your frontend domain in production

---

## 💰 Cost Estimates

| Service | Free Tier | Paid Tier |
|---------|-----------|-----------|
| Neon Database | ✅ Free (0.5GB) | $19/mo |
| Railway | ✅ $5 free credit/mo | Pay-as-you-go |
| Render | ✅ Free (with limits) | $7/mo |
| Supabase | ✅ Free (500MB) | $25/mo |

**Recommended Free Setup:** Neon + Railway = $0/month

---

## ❓ Need Help?

1. Check logs: `railway logs` or in dashboard
2. Check database connection
3. Verify environment variables
4. Check API health endpoint

Good luck! 🎮
