import { createServer } from 'http'
import { Server } from 'socket.io'

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// Types
interface User {
  id: string
  name: string
  rating: number
}

interface GameRoom {
  id: string
  whitePlayer: User
  blackPlayer: User
  boardState: string
  currentTurn: 'white' | 'black'
  status: 'playing' | 'finished'
  winner: 'white' | 'black' | 'draw' | null
  moves: Array<{ from: { row: number; col: number }; to: { row: number; col: number }; captures: Array<{ row: number; col: number }> }>
  timeControl: number
  whiteTime: number
  blackTime: number
  createdAt: Date
}

interface PendingMatch {
  userId: string
  userName: string
  userRating: number
  timeControl: number
  socketId: string
}

// State
const users = new Map<string, User>()
const gameRooms = new Map<string, GameRoom>()
const pendingMatches: PendingMatch[] = []
const userGameMap = new Map<string, string>() // socketId -> gameId

// Helper functions
const generateId = () => Math.random().toString(36).substr(2, 9)

// Initial board state for International Draughts
const getInitialBoard = () => {
  const board = []
  for (let row = 0; row < 10; row++) {
    board[row] = []
    for (let col = 0; col < 10; col++) {
      if ((row + col) % 2 === 1) {
        if (row < 4) {
          board[row][col] = { type: 'black', isKing: false }
        } else if (row > 5) {
          board[row][col] = { type: 'white', isKing: false }
        } else {
          board[row][col] = { type: null, isKing: false }
        }
      } else {
        board[row][col] = { type: null, isKing: false }
      }
    }
  }
  return JSON.stringify(board)
}

// Matchmaking
const findMatch = (pending: PendingMatch): PendingMatch | null => {
  const index = pendingMatches.findIndex(p => 
    p.userId !== pending.userId &&
    p.timeControl === pending.timeControl &&
    Math.abs(p.userRating - pending.userRating) < 200 // Rating range
  )
  
  if (index !== -1) {
    const match = pendingMatches[index]
    pendingMatches.splice(index, 1)
    return match
  }
  
  return null
}

const createGame = (player1: PendingMatch, player2: PendingMatch): GameRoom => {
  const gameId = generateId()
  const isWhite = Math.random() > 0.5
  
  const game: GameRoom = {
    id: gameId,
    whitePlayer: isWhite ? { id: player1.userId, name: player1.userName, rating: player1.userRating } : { id: player2.userId, name: player2.userName, rating: player2.userRating },
    blackPlayer: isWhite ? { id: player2.userId, name: player2.userName, rating: player2.userRating } : { id: player1.userId, name: player1.userName, rating: player1.userRating },
    boardState: getInitialBoard(),
    currentTurn: 'white',
    status: 'playing',
    winner: null,
    moves: [],
    timeControl: player1.timeControl,
    whiteTime: player1.timeControl,
    blackTime: player1.timeControl,
    createdAt: new Date()
  }
  
  gameRooms.set(gameId, game)
  userGameMap.set(player1.socketId, gameId)
  userGameMap.set(player2.socketId, gameId)
  
  return game
}

io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`)

  // Find a game
  socket.on('find-game', (data: { name: string; rating: number; timeControl: number }) => {
    const { name, rating, timeControl } = data
    
    const pending: PendingMatch = {
      userId: socket.id,
      userName: name,
      userRating: rating,
      timeControl,
      socketId: socket.id
    }
    
    const match = findMatch(pending)
    
    if (match) {
      // Create game
      const game = createGame(pending, match)
      
      // Join both players to the game room
      socket.join(game.id)
      const matchSocket = io.sockets.sockets.get(match.socketId)
      if (matchSocket) {
        matchSocket.join(game.id)
      }
      
      // Notify both players
      io.to(game.id).emit('game-started', {
        gameId: game.id,
        whitePlayer: game.whitePlayer,
        blackPlayer: game.blackPlayer,
        boardState: game.boardState,
        currentTurn: game.currentTurn,
        timeControl: game.timeControl
      })
      
      console.log(`Game ${game.id} started: ${game.whitePlayer.name} vs ${game.blackPlayer.name}`)
    } else {
      // Add to pending queue
      pendingMatches.push(pending)
      socket.emit('waiting-for-opponent')
      console.log(`${name} is waiting for an opponent`)
    }
  })

  // Cancel matchmaking
  socket.on('cancel-find', () => {
    const index = pendingMatches.findIndex(p => p.socketId === socket.id)
    if (index !== -1) {
      pendingMatches.splice(index, 1)
      console.log('Matchmaking cancelled')
    }
  })

  // Make a move
  socket.on('move', (data: { gameId: string; from: { row: number; col: number }; to: { row: number; col: number }; captures: Array<{ row: number; col: number }> }) => {
    const { gameId, from, to, captures } = data
    const game = gameRooms.get(gameId)
    
    if (!game) {
      socket.emit('error', { message: 'Game not found' })
      return
    }
    
    // Update game state
    game.moves.push({ from, to, captures })
    game.currentTurn = game.currentTurn === 'white' ? 'black' : 'white'
    
    // Broadcast move to both players
    io.to(gameId).emit('move-made', {
      from,
      to,
      captures,
      currentTurn: game.currentTurn,
      moveNumber: game.moves.length
    })
  })

  // Update board state (for sync)
  socket.on('update-board', (data: { gameId: string; boardState: string; currentTurn: 'white' | 'black' }) => {
    const game = gameRooms.get(data.gameId)
    if (game) {
      game.boardState = data.boardState
      game.currentTurn = data.currentTurn
    }
  })

  // Game over
  socket.on('game-over', (data: { gameId: string; winner: 'white' | 'black' | 'draw' }) => {
    const game = gameRooms.get(data.gameId)
    if (game) {
      game.status = 'finished'
      game.winner = data.winner
      
      io.to(data.gameId).emit('game-ended', {
        winner: data.winner,
        moves: game.moves
      })
    }
  })

  // Chat message
  socket.on('chat-message', (data: { gameId: string; message: string }) => {
    const gameId = data.gameId || userGameMap.get(socket.id)
    if (gameId) {
      const game = gameRooms.get(gameId)
      if (game) {
        const user = users.get(socket.id)
        io.to(gameId).emit('chat-message', {
          sender: user?.name || 'Unknown',
          content: data.message,
          time: new Date()
        })
      }
    }
  })

  // Resign
  socket.on('resign', (data: { gameId: string }) => {
    const game = gameRooms.get(data.gameId)
    if (game) {
      const user = users.get(socket.id)
      const winner = user?.id === game.whitePlayer.id ? 'black' : 'white'
      
      game.status = 'finished'
      game.winner = winner as 'white' | 'black'
      
      io.to(data.gameId).emit('game-ended', {
        winner,
        reason: 'resignation',
        resignedBy: user?.name
      })
    }
  })

  // Register user
  socket.on('register', (data: { name: string; rating: number }) => {
    users.set(socket.id, {
      id: socket.id,
      name: data.name,
      rating: data.rating
    })
    socket.emit('registered', { success: true })
  })

  // Disconnect
  socket.on('disconnect', () => {
    const user = users.get(socket.id)
    
    // Remove from pending matches
    const pendingIndex = pendingMatches.findIndex(p => p.socketId === socket.id)
    if (pendingIndex !== -1) {
      pendingMatches.splice(pendingIndex, 1)
    }
    
    // Handle ongoing games
    const gameId = userGameMap.get(socket.id)
    if (gameId) {
      const game = gameRooms.get(gameId)
      if (game && game.status === 'playing') {
        // Opponent wins by disconnect
        const winner = user?.id === game.whitePlayer.id ? 'black' : 'white'
        game.status = 'finished'
        game.winner = winner as 'white' | 'black'
        
        io.to(gameId).emit('game-ended', {
          winner,
          reason: 'disconnect',
          disconnectedPlayer: user?.name
        })
      }
      userGameMap.delete(socket.id)
    }
    
    users.delete(socket.id)
    console.log(`User disconnected: ${socket.id}`)
  })

  socket.on('error', (error) => {
    console.error(`Socket error (${socket.id}):`, error)
  })
})

const PORT = 3003
httpServer.listen(PORT, () => {
  console.log(`Draughts game service running on port ${PORT}`)
})

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM signal, shutting down server...')
  httpServer.close(() => {
    console.log('Game service closed')
    process.exit(0)
  })
})

process.on('SIGINT', () => {
  console.log('Received SIGINT signal, shutting down server...')
  httpServer.close(() => {
    console.log('Game service closed')
    process.exit(0)
  })
})
