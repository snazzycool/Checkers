// Environment
import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key-change-in-production';

// Middleware
app.use(cors({
  origin: '*', // In production, restrict this to your app domain
  credentials: true
}));
app.use(express.json());

// ============================================
// VALIDATION SCHEMAS
// ============================================

const registerSchema = z.object({
  username: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores'),
  email: z.string().email(),
  password: z.string().min(6),
  country: z.string().optional(),
  avatar: z.string().optional()
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
});

const updateProfileSchema = z.object({
  username: z.string().min(3).max(20).optional(),
  country: z.string().optional(),
  avatar: z.string().optional()
});

// ============================================
// AUTH MIDDLEWARE
// ============================================

interface AuthRequest extends express.Request {
  userId?: string;
  user?: any;
}

const authMiddleware = async (req: AuthRequest, res: express.Response, next: express.NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const token = authHeader.substring(7);
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        username: true,
        avatar: true,
        country: true,
        rating: true,
        gamesPlayed: true,
        gamesWon: true,
        gamesLost: true,
        createdAt: true
      }
    });

    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    req.userId = decoded.userId;
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// ============================================
// AUTH ROUTES
// ============================================

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const data = registerSchema.parse(req.body);
    
    // Check if email exists
    const existingEmail = await prisma.user.findUnique({
      where: { email: data.email }
    });
    if (existingEmail) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Check if username exists
    const existingUsername = await prisma.user.findUnique({
      where: { username: data.username }
    });
    if (existingUsername) {
      return res.status(400).json({ error: 'Username already taken' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(data.password, 10);

    // Create user
    const user = await prisma.user.create({
      data: {
        email: data.email,
        username: data.username,
        password: hashedPassword,
        country: data.country || null,
        avatar: data.avatar || '👤',
        authProvider: 'email'
      }
    });

    // Generate JWT
    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '30d' });

    res.status(201).json({
      message: 'Account created successfully',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        country: user.country,
        rating: user.rating,
        gamesPlayed: user.gamesPlayed,
        gamesWon: user.gamesWon,
        gamesLost: user.gamesLost
      },
      token
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors[0].message });
    }
    console.error('Register error:', error);
    res.status(500).json({ error: 'Failed to create account' });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const data = loginSchema.parse(req.body);

    // Find user
    const user = await prisma.user.findUnique({
      where: { email: data.email }
    });

    if (!user || !user.password) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Check password
    const validPassword = await bcrypt.compare(data.password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Update last seen
    await prisma.user.update({
      where: { id: user.id },
      data: { lastSeenAt: new Date() }
    });

    // Generate JWT
    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '30d' });

    res.json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        country: user.country,
        rating: user.rating,
        gamesPlayed: user.gamesPlayed,
        gamesWon: user.gamesWon,
        gamesLost: user.gamesLost
      },
      token
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors[0].message });
    }
    console.error('Login error:', error);
    res.status(500).json({ error: 'Failed to login' });
  }
});

// Google Sign-In (simplified - in production, verify Google token)
app.post('/api/auth/google', async (req, res) => {
  try {
    const { googleId, email, name, photoUrl } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    // Check if user exists
    let user = await prisma.user.findUnique({
      where: { email }
    });

    if (!user) {
      // Create new user
      const username = name || email.split('@')[0] + Math.floor(Math.random() * 1000);
      
      // Check if username exists
      const existingUsername = await prisma.user.findUnique({
        where: { username }
      });
      
      const finalUsername = existingUsername 
        ? username + Math.floor(Math.random() * 10000)
        : username;

      user = await prisma.user.create({
        data: {
          email,
          username: finalUsername,
          googleId: googleId || null,
          avatar: '🎮',
          authProvider: 'google'
        }
      });
    } else {
      // Update last seen
      await prisma.user.update({
        where: { id: user.id },
        data: { lastSeenAt: new Date() }
      });
    }

    // Generate JWT
    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '30d' });

    res.json({
      message: 'Google login successful',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        country: user.country,
        rating: user.rating,
        gamesPlayed: user.gamesPlayed,
        gamesWon: user.gamesWon,
        gamesLost: user.gamesLost
      },
      token
    });
  } catch (error) {
    console.error('Google login error:', error);
    res.status(500).json({ error: 'Failed to login with Google' });
  }
});

// Get current user
app.get('/api/auth/me', authMiddleware, async (req: AuthRequest, res) => {
  res.json({ user: req.user });
});

// ============================================
// USER ROUTES
// ============================================

// Get user profile
app.get('/api/users/:id', async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.params.id },
      select: {
        id: true,
        username: true,
        avatar: true,
        country: true,
        rating: true,
        gamesPlayed: true,
        gamesWon: true,
        gamesLost: true,
        createdAt: true
      }
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Failed to get user' });
  }
});

// Update profile
app.patch('/api/users/profile', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const data = updateProfileSchema.parse(req.body);

    // If changing username, check if it's taken
    if (data.username && data.username !== req.user.username) {
      const existing = await prisma.user.findUnique({
        where: { username: data.username }
      });
      if (existing) {
        return res.status(400).json({ error: 'Username already taken' });
      }
    }

    const user = await prisma.user.update({
      where: { id: req.userId },
      data: {
        username: data.username,
        country: data.country,
        avatar: data.avatar
      },
      select: {
        id: true,
        email: true,
        username: true,
        avatar: true,
        country: true,
        rating: true,
        gamesPlayed: true,
        gamesWon: true,
        gamesLost: true
      }
    });

    res.json({ message: 'Profile updated', user });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors[0].message });
    }
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// ============================================
// LEADERBOARD ROUTES
// ============================================

// Get leaderboard
app.get('/api/leaderboard', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 100;
    const offset = parseInt(req.query.offset as string) || 0;
    const country = req.query.country as string;

    const where = country ? { country } : {};

    const users = await prisma.user.findMany({
      where,
      orderBy: { rating: 'desc' },
      take: limit,
      skip: offset,
      select: {
        id: true,
        username: true,
        avatar: true,
        country: true,
        rating: true,
        gamesPlayed: true,
        gamesWon: true,
        gamesLost: true
      }
    });

    // Add rank
    const leaderboard = users.map((user, index) => ({
      ...user,
      rank: offset + index + 1,
      winRate: user.gamesPlayed > 0 
        ? Math.round((user.gamesWon / user.gamesPlayed) * 100) 
        : 0
    }));

    res.json({ leaderboard });
  } catch (error) {
    console.error('Leaderboard error:', error);
    res.status(500).json({ error: 'Failed to get leaderboard' });
  }
});

// Get user rank
app.get('/api/leaderboard/rank/:userId', async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.params.userId },
      select: { rating: true }
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Count users with higher rating
    const higherRatedCount = await prisma.user.count({
      where: { rating: { gt: user.rating } }
    });

    res.json({ rank: higherRatedCount + 1 });
  } catch (error) {
    console.error('Get rank error:', error);
    res.status(500).json({ error: 'Failed to get rank' });
  }
});

// ============================================
// GAME ROUTES
// ============================================

// Submit game result
app.post('/api/games', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { opponentId, winner, resultReason, timeControl, movesCount, moves } = req.body;

    if (!opponentId || !timeControl) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Create game record
    const game = await prisma.game.create({
      data: {
        whiteId: req.userId!,
        blackId: opponentId,
        winner,
        resultReason,
        timeControl,
        movesCount: movesCount || 0,
        moves: moves ? JSON.stringify(moves) : null,
        endedAt: new Date()
      }
    });

    // Update stats
    const isWhite = req.userId !== opponentId; // Simplified
    const isWinner = winner === 'white' || winner === 'black'; // Simplified
    
    // Update player stats
    await prisma.user.update({
      where: { id: req.userId! },
      data: {
        gamesPlayed: { increment: 1 },
        gamesWon: winner === 'white' ? { increment: 1 } : undefined,
        gamesLost: winner === 'black' ? { increment: 1 } : undefined,
        rating: winner === 'white' ? { increment: 15 } : { decrement: 10 }
      }
    });

    res.json({ message: 'Game recorded', game });
  } catch (error) {
    console.error('Submit game error:', error);
    res.status(500).json({ error: 'Failed to submit game' });
  }
});

// Get recent games
app.get('/api/games/recent', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 20;

    const games = await prisma.game.findMany({
      where: { endedAt: { not: null } },
      orderBy: { endedAt: 'desc' },
      take: limit,
      include: {
        white: {
          select: { id: true, username: true, avatar: true, country: true, rating: true }
        },
        black: {
          select: { id: true, username: true, avatar: true, country: true, rating: true }
        }
      }
    });

    res.json({ games });
  } catch (error) {
    console.error('Get games error:', error);
    res.status(500).json({ error: 'Failed to get games' });
  }
});

// Get user's games
app.get('/api/games/user/:userId', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;

    const games = await prisma.game.findMany({
      where: {
        OR: [
          { whiteId: req.params.userId },
          { blackId: req.params.userId }
        ],
        endedAt: { not: null }
      },
      orderBy: { endedAt: 'desc' },
      take: limit,
      include: {
        white: {
          select: { id: true, username: true, avatar: true, country: true, rating: true }
        },
        black: {
          select: { id: true, username: true, avatar: true, country: true, rating: true }
        }
      }
    });

    res.json({ games });
  } catch (error) {
    console.error('Get user games error:', error);
    res.status(500).json({ error: 'Failed to get user games' });
  }
});

// ============================================
// STATS ROUTES
// ============================================

// Get global stats
app.get('/api/stats', async (req, res) => {
  try {
    const [totalUsers, totalGames, avgRating] = await Promise.all([
      prisma.user.count(),
      prisma.game.count(),
      prisma.user.aggregate({
        _avg: { rating: true }
      })
    ]);

    res.json({
      totalUsers,
      totalGames,
      averageRating: Math.round(avgRating._avg.rating || 1500)
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

// ============================================
// HEALTH CHECK
// ============================================

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.get('/', (req, res) => {
  res.json({ 
    message: 'International Draughts API',
    version: '1.0.0',
    endpoints: {
      auth: '/api/auth/register, /api/auth/login, /api/auth/google, /api/auth/me',
      users: '/api/users/:id, /api/users/profile',
      leaderboard: '/api/leaderboard, /api/leaderboard/rank/:userId',
      games: '/api/games, /api/games/recent, /api/games/user/:userId',
      stats: '/api/stats'
    }
  });
});

// ============================================
// START SERVER
// ============================================

const server = app.listen(PORT, () => {
  console.log(`🚀 Draughts Backend API running on port ${PORT}`);
  console.log(`📡 Health check: http://localhost:${PORT}/api/health`);
});

// Handle shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down...');
  await prisma.$disconnect();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

export { app, prisma };
