# 🎮 International Draughts Backend Service

A production-ready Node.js backend API for the International Draughts game.

## Features

- 🔐 **Authentication** - Email/Password & Google Sign-In
- 👤 **User Management** - Profiles, stats, avatars
- 🏆 **Leaderboard** - Real-time rankings with ELO ratings
- 📊 **Game History** - Store and retrieve game results
- 📈 **Statistics** - Global and user stats

## Tech Stack

- **Runtime**: Bun
- **Framework**: Express.js
- **Database**: PostgreSQL (Prisma ORM)
- **Auth**: JWT tokens with bcrypt password hashing

## Quick Start

### 1. Install Dependencies

```bash
cd mini-services/backend-service
bun install
```

### 2. Set up Environment

Create `.env` file:

```env
DATABASE_URL="postgresql://user:password@host:5432/draughts?schema=public"
JWT_SECRET="your-super-secret-key-min-32-chars"
PORT=3001
```

### 3. Initialize Database

```bash
bunx prisma generate
bunx prisma db push
```

### 4. Start Server

```bash
bun run dev
```

Server runs at: http://localhost:3001

## API Endpoints

### Authentication

```
POST /api/auth/register
POST /api/auth/login
POST /api/auth/google
GET  /api/auth/me
```

### Users

```
GET    /api/users/:id
PATCH  /api/users/profile
```

### Leaderboard

```
GET /api/leaderboard
GET /api/leaderboard/rank/:userId
```

### Games

```
POST /api/games
GET  /api/games/recent
GET  /api/games/user/:userId
```

### Stats

```
GET /api/stats
```

## Request Examples

### Register

```bash
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "player1",
    "email": "player@example.com",
    "password": "securepassword123",
    "country": "NG",
    "avatar": "🎮"
  }'
```

### Login

```bash
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "player@example.com",
    "password": "securepassword123"
  }'
```

### Get Leaderboard

```bash
curl http://localhost:3001/api/leaderboard?limit=100
```

### Submit Game Result

```bash
curl -X POST http://localhost:3001/api/games \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "opponentId": "user-xxx",
    "winner": "white",
    "resultReason": "capture",
    "timeControl": 600,
    "movesCount": 45
  }'
```

## Deployment

### Railway (Recommended)

1. Push code to GitHub
2. Create new project on [Railway](https://railway.app)
3. Add PostgreSQL database
4. Deploy from GitHub
5. Set environment variables

### Render

1. Create account on [Render](https://render.com)
2. New Web Service → Connect GitHub
3. Set root directory: `mini-services/backend-service`
4. Add environment variables
5. Deploy

### Docker

```bash
docker build -t draughts-backend .
docker run -p 3001:3001 draughts-backend
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | PostgreSQL connection string |
| `JWT_SECRET` | Yes | Secret key for JWT (32+ chars) |
| `PORT` | No | Server port (default: 3001) |

## Database Schema

```prisma
model User {
  id          String   @id
  email       String   @unique
  username    String   @unique
  password    String?
  avatar      String
  country     String?
  rating      Int
  gamesPlayed Int
  gamesWon    Int
  gamesLost   Int
  createdAt   DateTime
}

model Game {
  id          String
  whiteId     String
  blackId     String
  winner      String?
  timeControl Int
  endedAt     DateTime
}
```

## Security

- Passwords hashed with bcrypt (10 rounds)
- JWT tokens expire after 30 days
- CORS enabled for cross-origin requests
- Input validation with Zod schemas

## License

MIT
